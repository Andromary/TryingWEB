<?php

$pages_array = [
    'index.php'             => 'Главная',
    // 'about.php'             => 'Давайте знакомиться',
    // 'possibilities.php'     => 'Что мы можем',
    // 'advantages.php'        => 'Наши преимущества', // 'Почему мы'
    'reports_data.php'      => 'Исходные данные',
    'report_example.php'    => 'Пример отчетов',
    'study.php'             => 'Интересное по теме',
    'contacts.php'          => 'Свяжитесь с нами',
    'registration.php'      => 'Регистрация',
    'enter.php'             => 'Войти',
    'personal_account.php'  => 'Личный кабинет'
];