// required = "required" // в <input id="emailsignup" name="emailsignup" required="required" type="text" placeholder="mysupermail@mail.com"/>
// но тогда не высветятся ошибки!
    // < form  action = "mysuperscript.php" autocomplete = "on" >


// если сессия не установлена,
// при переходе на сайт высвечиваются регистрация и войти.
// элемент личный кабинет скрыт

// если сессия установлена, скрыты вход и регистрация, а лк виден

// получить этементы - ссылки регистрация, войти, лк
// если сессия установлена задать элементам войти и регистрация аттрибут hidden
// console.log(123);
let buyer = document.querySelector('.buyer');
console.log(registration);
let enter = document.querySelector('.enter.php');
let personalAccount = document.querySelector('.personal_account.php');




// classList.toggle()


// let button = document.querySelector('button');
// console.log(button);
// let hidden = document.querySelector('.hidden');

// button.addEventListener('click', function(){
//     hidden.classList.toggle('hidden');
// });