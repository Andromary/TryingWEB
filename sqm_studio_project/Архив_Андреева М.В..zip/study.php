<!-- useful information
https://finmodel.bz/#uslugi#!/tab/232710371-2 -->
<?php
require 'pages_array.php';
$tytle = $pages_array['study.php'];
require 'components/header.php';
?>

        <section class="main-block main-block__content study">
            <h1>!!!Раздел на стадии разработки!!!</h1>
            <h3>Здесь будут: нормативные документы (выдержки) и статьи по теме управления качеством поставщиков и/или ссылки на первоисточники.</h3>

        </section>

<?php
require 'components/footer.php';
?>