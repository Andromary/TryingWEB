<!-- Описание деятельности (в о нас)
Обоснование актуальности проблемы?
- почему именно мы (в возможности)-->
<?php
require 'pages_array.php';
$tytle = ' современная платформа для управления Вашими поставщиками';
require 'components/header.php';
require 'components/main.php';
require 'components/footer.php';
session_start();

?>